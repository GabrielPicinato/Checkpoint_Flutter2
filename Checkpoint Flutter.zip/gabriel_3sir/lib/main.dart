import 'package:gabriel_3sir/pages/main_page.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}