class alunoNota {
  String aluno;
  String nota;

  alunoNota({
    required this.aluno,
    required this.nota,
  });
}
