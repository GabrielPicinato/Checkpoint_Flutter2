import 'package:gabriel_3sir/pages/components/gabriel_card.dart';
import 'package:gabriel_3sir/pages/components/gabriel_form.dart';
import 'package:flutter/material.dart';
import 'components/gabriel_page.dart';
import 'model/aluno_nota_model.dart';

class ListPage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _ListPageState();
  }
}

class _ListPageState extends State<ListPage> {
  TextEditingController alunoController = TextEditingController();
  TextEditingController notaController = TextEditingController();
  FocusNode alunoFocus = FocusNode();
  FocusNode notaFocus = FocusNode();

  List<alunoNota> alunoNotaList = [
    alunoNota(aluno: 'José', nota: '5'),
    alunoNota(aluno: 'Pedro', nota: '6'),
    alunoNota(aluno: 'Yuri', nota: '9'),
    alunoNota(aluno: 'Ruan', nota: '2'), 
    alunoNota(aluno: 'Joao', nota: '10'), 
  ];

  cadastrarNota({required String aluno, required String nota}) {
    setState(() {
      alunoNotaList.insert(
        0,
        alunoNota(
          aluno: aluno,
          nota: nota,
        ),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return StandardPage(
      title: 'Insira o nome do aluno e a nota',
      body: SingleChildScrollView(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(20.0),
              child: StandardForm(
                label: 'Aluno',
                focusNode: alunoFocus,
                userInputController: alunoController,
                onEditingComplete: () {
                  notaFocus.nextFocus();
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(20.0),
              child: StandardForm(
                label: 'Nota',
                focusNode: notaFocus,
                userInputController: notaController,
              ),
            ),
            const SizedBox(height: 10),
            ListView.separated(
                separatorBuilder: (BuildContext context, int index) {
                  return const SizedBox(
                    height: 8,
                  );
                },
                shrinkWrap: true,
                itemCount: alunoNotaList.length,
                itemBuilder: (context, index) {
                  var registrarnota = alunoNotaList[index];
                  return MouseRegion(
                    cursor: SystemMouseCursors.click,
                    child: GestureDetector(
                      child: gabrielCard(
                        leftText: registrarnota.aluno,
                        rightText: registrarnota.nota,
                      ),
                    ),
                  );
                }),
          ],
        ),
      ),
      botao: FloatingActionButton(
        child: Icon(Icons.add_task),
        onPressed: () {
          cadastrarNota(
              aluno: alunoController.text, nota: notaController.text);
        },
      ),
    );
  }
}
