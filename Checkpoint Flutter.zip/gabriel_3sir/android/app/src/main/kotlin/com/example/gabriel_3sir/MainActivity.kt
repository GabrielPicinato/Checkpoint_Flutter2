package com.example.gabriel_3sir

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
